# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
BtcjamClient::Application.config.secret_token = '4c8e2af4d0a13797cbedba84c7f2908a5bb901e7408614cfe693be5b6580539b676e07f065c353de851fb0ee54bb0864db28d8643c46875657e9143175c0fc21'
