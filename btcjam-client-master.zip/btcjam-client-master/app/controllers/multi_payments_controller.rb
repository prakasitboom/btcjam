class MultiPaymentsController < ApplicationController
  def index
    
  end
end