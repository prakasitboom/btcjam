class ReferencesController < ApplicationController
  def index
    
  end
end